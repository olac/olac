import ia_harvester
ia_harvester.harvest_ia('LanguageCommons', 'LanguageCommons.xml')

