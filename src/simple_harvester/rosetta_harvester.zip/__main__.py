import ia_harvester
ia_harvester.harvest_ia('rosettaproject', 'rosetta.xml')

